import React, { useState } from "react";
import EnvelopeEditor from "./EnvelopeEditor";

function App() {
  const [content, setContent] = useState("");

  return (
    <div style={{ padding: "20px" }}>
      <h2>Envelope Editor</h2>

      <EnvelopeEditor value={content} onChange={setContent} />

      <h3>Output HTML:</h3>
      <pre>{content}</pre>
    </div>
  );
}

export default App;