import { useState, useRef, useEffect, useCallback } from "react";
import "./Editor.css";

const FONTS = ["Arial","Georgia","Times New Roman","Courier New","Verdana","Trebuchet MS","Comic Sans MS","Impact","Tahoma","Palatino"];
const FONT_SIZES = [8,9,10,11,12,14,16,18,20,22,24,26,28,36,48,72];
const LINE_HEIGHTS = [{label:"Single",val:"1"},{label:"1.15",val:"1.15"},{label:"1.5",val:"1.5"},{label:"Double",val:"2"}];
const MERGE_FIELDS = ["FirstName","LastName","FullName","Email","Phone","Company","JobTitle","Address","City","State","ZipCode","Country","Date","Signature","AccountNumber"];

function ToolbarDivider() {
  return <div className="ee-toolbar-divider"/>;
}
function TBtn({title,onClick,active,children,style={},className=""}) {
  return (
    <button title={title} onMouseDown={function(e){e.preventDefault();onClick&&onClick();}}
      className={"ee-btn"+(active?" is-active":"")+(className?" "+className:"")}
      style={style}>
      {children}
    </button>
  );
}
function Dropdown({value,options,onChange,width,className=""}) {
  return (
    <select value={value} onChange={function(e){onChange(e.target.value);}} onMouseDown={function(e){e.stopPropagation();}}
      className={"ee-dropdown"+(className?" "+className:"")}
      style={{width:width||120}}>
      {options.map(function(o){
        return typeof o==="object"
          ? <option key={o.val} value={o.val}>{o.label}</option>
          : <option key={o} value={o}>{o}</option>;
      })}
    </select>
  );
}

export default function DocsEditor() {
  const editorRef = useRef(null);
  const fileInputRef = useRef(null);
  const docUploadRef = useRef(null);
  const savedRange = useRef(null);

  const [activeFormats, setActiveFormats] = useState({});
  const [fontFamily, setFontFamily] = useState("Arial");
  const [fontSize, setFontSize] = useState("12");
  const [textColor, setTextColor] = useState("#000000");
  const [bgColor, setBgColor] = useState("#ffff00");
  const [wordSpacing, setWordSpacing] = useState("normal");
  const [lineHeight, setLineHeight] = useState("1.15");
  const [selectedImg, setSelectedImg] = useState(null);
  const [imgPanel, setImgPanel] = useState({show:false,x:0,y:0});
  const [showPreview, setShowPreview] = useState(false);
  const [mergeValues, setMergeValues] = useState({});

  useEffect(function(){
    if(window.docx) return;
    var s = document.createElement("script");
    s.src = "https://unpkg.com/docx@8.5.0/build/index.umd.js";
    document.head.appendChild(s);
    // mammoth for docx upload
    var s2 = document.createElement("script");
    s2.src = "https://cdn.jsdelivr.net/npm/mammoth@1.6.0/mammoth.browser.min.js";
    document.head.appendChild(s2);
  },[]);

  function saveRange() {
    var sel = window.getSelection();
    if(sel && sel.rangeCount>0) savedRange.current = sel.getRangeAt(0).cloneRange();
  }
  function restoreRange() {
    var sel = window.getSelection();
    if(savedRange.current && sel){ sel.removeAllRanges(); sel.addRange(savedRange.current); }
  }
  function updateActive() {
    setActiveFormats({
      bold:document.queryCommandState("bold"),
      italic:document.queryCommandState("italic"),
      underline:document.queryCommandState("underline"),
      strikeThrough:document.queryCommandState("strikeThrough"),
      superscript:document.queryCommandState("superscript"),
      subscript:document.queryCommandState("subscript"),
      insertUnorderedList:document.queryCommandState("insertUnorderedList"),
      insertOrderedList:document.queryCommandState("insertOrderedList"),
      justifyLeft:document.queryCommandState("justifyLeft"),
      justifyCenter:document.queryCommandState("justifyCenter"),
      justifyRight:document.queryCommandState("justifyRight"),
      justifyFull:document.queryCommandState("justifyFull"),
    });
    var ff = document.queryCommandValue("fontName");
    if(ff) setFontFamily(ff.replace(/['"]/g,""));
  }

  var exec = useCallback(function(cmd,val){
    if(editorRef.current){
      editorRef.current.focus();
      var sel=window.getSelection();
      if(savedRange.current&&sel&&sel.rangeCount===0){ sel.removeAllRanges(); sel.addRange(savedRange.current); }
    }
    document.execCommand(cmd,false,val||null);
    updateActive();
  },[]);

  function applySpanStyle(prop,val) {
    var sel=window.getSelection(); if(!sel||sel.rangeCount===0) return;
    restoreRange();
    var sel2=window.getSelection(); if(!sel2||sel2.rangeCount===0||sel2.isCollapsed) return;
    var range=sel2.getRangeAt(0);
    var frag=range.extractContents();
    frag.querySelectorAll("span").forEach(function(sp){ if(sp.style[prop]) sp.style[prop]=""; });
    var walker=document.createTreeWalker(frag,NodeFilter.SHOW_TEXT,null,false);
    var nodes=[]; var n; while((n=walker.nextNode())) nodes.push(n);
    if(!nodes.length){ range.insertNode(frag); return; }
    nodes.forEach(function(tn){
      if(!tn.textContent) return;
      var sp=document.createElement("span");
      sp.style[prop]=val;
      if(prop==="fontSize") sp.style.lineHeight="1.15";
      tn.parentNode.insertBefore(sp,tn); sp.appendChild(tn);
    });
    range.insertNode(frag);
    if(prop==="fontSize"){
      var el=editorRef.current;
      var blocks=el?el.querySelectorAll("p,div,li,h1,h2,h3,h4,h5,h6"):[];
      try{ var r2=sel2.getRangeAt(0); blocks.forEach(function(b){ if(r2.intersectsNode(b)) b.style.lineHeight="normal"; }); }catch(e){}
    }
    sel2.removeAllRanges(); sel2.addRange(range);
  }

  function applyBlockStyle(prop,val) {
    var sel=window.getSelection(); if(!sel||sel.rangeCount===0) return;
    var range=sel.getRangeAt(0); var el=editorRef.current; if(!el) return;
    var blocks=el.querySelectorAll("p,div,li,h1,h2,h3,h4,h5,h6,blockquote");
    if(sel.isCollapsed){
      var node=sel.anchorNode;
      while(node&&node!==el){ if(node.style!==undefined){node.style[prop]=val;break;} node=node.parentNode; }
    } else {
      blocks.forEach(function(b){ if(range.intersectsNode(b)) b.style[prop]=val; });
    }
  }

  function applyFont(f){ setFontFamily(f); saveRange(); editorRef.current&&editorRef.current.focus(); restoreRange(); applySpanStyle("fontFamily",f); }
  function applySize(s){ setFontSize(s); saveRange(); editorRef.current&&editorRef.current.focus(); restoreRange(); applySpanStyle("fontSize",s+"pt"); }
  function applyColor(c){ setTextColor(c); saveRange(); editorRef.current&&editorRef.current.focus(); restoreRange(); applySpanStyle("color",c); }
  function applyBg(c){ setBgColor(c); saveRange(); editorRef.current&&editorRef.current.focus(); restoreRange(); applySpanStyle("backgroundColor",c); }
  function applyLineHeight(v){ setLineHeight(v); saveRange(); editorRef.current&&editorRef.current.focus(); restoreRange(); applyBlockStyle("lineHeight",v); }
  function applyWordSpacing(v){ setWordSpacing(v); saveRange(); editorRef.current&&editorRef.current.focus(); restoreRange(); applySpanStyle("wordSpacing",v); }

  function insertLink(){ var url=prompt("Enter URL:","https://"); if(url) exec("createLink",url); }
  function insertHr(){ exec("insertHTML","<hr style='border:none;border-top:1px solid #ccc;margin:12px 0'/>"); }
  function insertTable(){
    var r=parseInt(prompt("Rows:","3")||"3"), c=parseInt(prompt("Columns:","3")||"3");
    var html="<table style='border-collapse:collapse;width:100%;margin:8px 0'>";
    for(var i=0;i<r;i++){ html+="<tr>"; for(var j=0;j<c;j++) html+="<td style='border:1px solid #ccc;padding:6px 8px;min-width:60px'>&nbsp;</td>"; html+="</tr>"; }
    exec("insertHTML",html+"</table><p><br></p>");
  }

  function insertMergeField(field){
    if(!field) return;
    editorRef.current&&editorRef.current.focus();
    var sel=window.getSelection();
    if(savedRange.current&&sel&&sel.rangeCount===0){ sel.removeAllRanges(); sel.addRange(savedRange.current); }
    var ff="inherit",fs="inherit",fw="inherit",fi="normal",tc="inherit";
    if(sel&&sel.rangeCount>0){
      var node=sel.getRangeAt(0).startContainer;
      if(node.nodeType===3) node=node.parentElement;
      if(node){ var cs=window.getComputedStyle(node); ff=cs.fontFamily||"inherit"; fs=cs.fontSize||"inherit"; fw=cs.fontWeight||"inherit"; fi=cs.fontStyle||"normal"; tc=cs.color||"inherit"; }
    }
    document.execCommand("insertHTML",false,"<span style=\"font-family:"+ff+";font-size:"+fs+";font-weight:"+fw+";font-style:"+fi+";color:"+tc+";background:#e8f0fe;border-radius:3px;padding:1px 4px;\">["+field+"]</span>");
    updateActive();
  }

  function getPreviewHtml(){
    var html=editorRef.current?editorRef.current.innerHTML:"";
    MERGE_FIELDS.forEach(function(f){
      var val=mergeValues[f]; if(!val) return;
      html=html.replace(new RegExp("(<span[^>]*>)\\["+f+"\\](<\\/span>)","g"),"$1"+val+"$2");
      html=html.replace(new RegExp("\\["+f+"\\]","g"),val);
    });
    return html.replace(/background:#e8f0fe;/g,"background:transparent;");
  }

  function rgbToHex(rgb){
    var m=rgb.match(/\d+/g);
    if(!m||m.length<3) return "000000";
    return m.slice(0,3).map(function(n){ return parseInt(n).toString(16).padStart(2,"0"); }).join("");
  }

  function getImageDimensions(src){
    return new Promise(function(resolve){
      var img=new Image();
      img.onload=function(){ resolve({w:img.naturalWidth,h:img.naturalHeight}); };
      img.onerror=function(){ resolve({w:300,h:200}); };
      img.src=src;
    });
  }

  function dataUrlToUint8Array(dataUrl){
    var base64=dataUrl.split(",")[1];
    var binary=atob(base64);
    var arr=new Uint8Array(binary.length);
    for(var i=0;i<binary.length;i++) arr[i]=binary.charCodeAt(i);
    return arr;
  }

  async function downloadDOCX(){
    if(!window.docx){ alert("DOCX library still loading, please try again."); return; }
    var D=window.docx;
    var el=editorRef.current; if(!el) return;
    var children=[];

    async function walkNodeForRuns(node,runs,cs){
      if(node.nodeType===3){
        if(node.textContent) runs.push(new D.TextRun({text:node.textContent,bold:cs.bold,italics:cs.italic,underline:cs.under?{}:undefined,strike:cs.strike,size:cs.size,color:cs.color}));
        return;
      }
      if(node.nodeType!==1) return;
      var tag=node.tagName.toLowerCase();
      if(tag==="img"){
        if(node.src&&node.src.startsWith("data:")){
          try{
            var dims=await getImageDimensions(node.src);
            var dw=node.offsetWidth||parseInt(node.style.width)||300;
            var dh=node.offsetHeight||Math.round(dw*(dims.h/dims.w));
            var scale=Math.min(1,500/dw);
            var ext=node.src.indexOf("image/png")>-1?"png":node.src.indexOf("image/gif")>-1?"gif":"jpg";
            runs.push(new D.ImageRun({data:dataUrlToUint8Array(node.src),transformation:{width:Math.round(dw*scale),height:Math.round(dh*scale)},type:ext}));
          }catch(err){}
        }
        return;
      }
      var nc=window.getComputedStyle(node);
      var ncs={
        bold:nc.fontWeight==="bold"||parseInt(nc.fontWeight)>=600,
        italic:nc.fontStyle==="italic",
        under:nc.textDecoration.includes("underline"),
        strike:nc.textDecoration.includes("line-through"),
        size:Math.round(parseFloat(nc.fontSize||"12")*1.5),
        color:nc.color?rgbToHex(nc.color):"000000"
      };
      for(var i=0;i<node.childNodes.length;i++){
        await walkNodeForRuns(node.childNodes[i],runs,ncs);
      }
    }

    async function processBlock(block){
      var tag=block.tagName.toLowerCase();
      var hl=undefined;
      if(tag==="h1") hl=D.HeadingLevel.HEADING_1;
      else if(tag==="h2") hl=D.HeadingLevel.HEADING_2;
      else if(tag==="h3") hl=D.HeadingLevel.HEADING_3;
      var ta=block.style.textAlign||window.getComputedStyle(block).textAlign||"left";
      var al=D.AlignmentType.LEFT;
      if(ta==="center") al=D.AlignmentType.CENTER;
      else if(ta==="right") al=D.AlignmentType.RIGHT;
      else if(ta==="justify") al=D.AlignmentType.JUSTIFIED;
      var runs=[];
      var basecs={bold:false,italic:false,under:false,strike:false,size:24,color:"000000"};
      for(var i=0;i<block.childNodes.length;i++){
        await walkNodeForRuns(block.childNodes[i],runs,basecs);
      }
      if(runs.length===0&&block.innerText&&block.innerText.trim()){
        runs.push(new D.TextRun({text:block.innerText}));
      }
      if(runs.length>0) children.push(new D.Paragraph({heading:hl,alignment:al,children:runs}));
    }

    var topNodes=Array.from(el.childNodes);
    for(var i=0;i<topNodes.length;i++){
      var node=topNodes[i];
      if(node.nodeType!==1) continue;
      var tag=node.tagName.toLowerCase();
      if(["p","h1","h2","h3","li","div","blockquote"].includes(tag)){
        await processBlock(node);
      } else if(tag==="span"&&node.classList.contains("img-wrapper")){
        var imgEl=node.querySelector("img");
        if(imgEl&&imgEl.src&&imgEl.src.startsWith("data:")){
          try{
            var dims=await getImageDimensions(imgEl.src);
            var dw=imgEl.offsetWidth||300;
            var dh=imgEl.offsetHeight||Math.round(dw*(dims.h/dims.w));
            var scale=Math.min(1,500/dw);
            var ext=imgEl.src.indexOf("image/png")>-1?"png":imgEl.src.indexOf("image/gif")>-1?"gif":"jpg";
            children.push(new D.Paragraph({children:[new D.ImageRun({data:dataUrlToUint8Array(imgEl.src),transformation:{width:Math.round(dw*scale),height:Math.round(dh*scale)},type:ext})]}));
          }catch(err){}
        }
      }
    }

    if(children.length===0) children.push(new D.Paragraph({children:[new D.TextRun({text:el.innerText})]}));
    var doc=new D.Document({sections:[{children:children}]});
    var blob=await D.Packer.toBlob(doc);
    var a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="document.docx"; a.click();
  }

  function uploadDoc(e){
    var file=e.target.files[0]; if(!file) return;
    var reader=new FileReader();
    if(file.name.endsWith(".docx")){
      reader.onload=function(ev){
        if(!window.mammoth){ alert("Mammoth library still loading, please try again."); return; }
        window.mammoth.convertToHtml({arrayBuffer:ev.target.result})
          .then(function(result){
            editorRef.current.innerHTML=result.value;
            setupImages();
          })
          .catch(function(err){ alert("Error reading DOCX: "+err.message); });
      };
      reader.readAsArrayBuffer(file);
    } else {
      reader.onload=function(ev){
        if(file.name.endsWith(".html")) editorRef.current.innerHTML=ev.target.result;
        else editorRef.current.innerHTML="<p>"+ev.target.result.replace(/\n/g,"</p><p>")+"</p>";
        setupImages();
      };
      reader.readAsText(file);
    }
    e.target.value="";
  }

  function downloadHTML(){
    var html="<!DOCTYPE html><html><head><meta charset=\"utf-8\"><style>body{font-family:Arial;font-size:12pt;line-height:1.15;margin:72px 96px;color:#000;}p{margin:0 0 2px 0;}ul{list-style-type:disc;padding-left:28px;}ol{list-style-type:decimal;padding-left:28px;}</style></head><body>"+editorRef.current.innerHTML+"</body></html>";
    var a=document.createElement("a"); a.href=URL.createObjectURL(new Blob([html],{type:"text/html"})); a.download="document.html"; a.click();
  }
  function downloadTXT(){
    var a=document.createElement("a"); a.href=URL.createObjectURL(new Blob([editorRef.current.innerText],{type:"text/plain"})); a.download="document.txt"; a.click();
  }
  function printDoc(){
    var html="<!DOCTYPE html><html><head><meta charset=\"utf-8\"><style>body{font-family:Arial;font-size:12pt;line-height:1.15;margin:72px 96px;color:#000;}p{margin:0 0 2px 0;}</style></head><body>"+editorRef.current.innerHTML+"</body></html>";
    var win=window.open("","_blank"); win.document.write(html); win.document.close(); win.focus();
    setTimeout(function(){ win.print(); win.close(); },400);
  }

  function clearAllWrappers(){
    if(!editorRef.current) return;
    editorRef.current.querySelectorAll(".img-wrapper").forEach(function(w){
      w.style.outline="none"; w.style.outlineOffset="0px";
      w.querySelectorAll(".rh").forEach(function(h){ h.style.display="none"; });
    });
    setImgPanel({show:false,x:0,y:0}); setSelectedImg(null);
  }

  var setupImages = useCallback(function(){
    if(!editorRef.current) return;
    editorRef.current.querySelectorAll("img.doc-img").forEach(function(img){
      if(img.dataset.wrapped) return;
      img.dataset.wrapped="1";
      var wrapper=document.createElement("span");
      wrapper.className="img-wrapper";
      wrapper.style.cssText="display:inline-block;position:relative;line-height:0;";
      img.parentNode.insertBefore(wrapper,img); wrapper.appendChild(img);
      img.style.display="block"; if(!img.style.width) img.style.width="300px";

      function makeHandle(cursor,posStyles){
        var h=document.createElement("div"); h.className="rh";
        h.style.cssText="position:absolute;width:10px;height:10px;background:#1a73e8;border:2px solid #fff;border-radius:50%;z-index:10;box-sizing:border-box;display:none;cursor:"+cursor+";"+posStyles;
        return h;
      }
      var hdefs=[
        {cursor:"nwse-resize",pos:"bottom:-5px;right:-5px;",dir:"se"},
        {cursor:"nesw-resize",pos:"bottom:-5px;left:-5px;",dir:"sw"},
        {cursor:"nwse-resize",pos:"top:-5px;left:-5px;",dir:"nw"},
        {cursor:"nesw-resize",pos:"top:-5px;right:-5px;",dir:"ne"},
        {cursor:"ew-resize",pos:"top:calc(50% - 5px);right:-5px;",dir:"e"},
        {cursor:"ew-resize",pos:"top:calc(50% - 5px);left:-5px;",dir:"w"},
        {cursor:"ns-resize",pos:"left:calc(50% - 5px);top:-5px;",dir:"n"},
        {cursor:"ns-resize",pos:"left:calc(50% - 5px);bottom:-5px;",dir:"s"},
      ];
      hdefs.forEach(function(def){
        var h=makeHandle(def.cursor,def.pos); var dir=def.dir;
        h.addEventListener("mousedown",function(e){
          e.preventDefault(); e.stopPropagation();
          var sx=e.clientX,sy=e.clientY,sw=img.offsetWidth,sh=img.offsetHeight,ar=sw/sh;
          function mv(ev){
            var dx=ev.clientX-sx,dy=ev.clientY-sy; var nw=sw,nh=sh;
            if(dir==="se"){ nw=Math.max(50,sw+dx); nh=nw/ar; }
            else if(dir==="sw"){ nw=Math.max(50,sw-dx); nh=nw/ar; }
            else if(dir==="ne"){ nw=Math.max(50,sw+dx); nh=nw/ar; }
            else if(dir==="nw"){ nw=Math.max(50,sw-dx); nh=nw/ar; }
            else if(dir==="e"){ nw=Math.max(50,sw+dx); nh=sh; }
            else if(dir==="w"){ nw=Math.max(50,sw-dx); nh=sh; }
            else if(dir==="s"){ nh=Math.max(30,sh+dy); nw=sw; }
            else if(dir==="n"){ nh=Math.max(30,sh-dy); nw=sw; }
            img.style.width=nw+"px"; img.style.height=nh+"px";
          }
          function up(){ document.removeEventListener("mousemove",mv); document.removeEventListener("mouseup",up); }
          document.addEventListener("mousemove",mv); document.addEventListener("mouseup",up);
        });
        wrapper.appendChild(h);
      });

      function selectWrapper(){
        clearAllWrappers();
        setTimeout(function(){
          setSelectedImg(img);
          wrapper.querySelectorAll(".rh").forEach(function(h){ h.style.display="block"; });
          wrapper.style.outline="2px solid #1a73e8"; wrapper.style.outlineOffset="2px";
          var r2=wrapper.getBoundingClientRect();
          var er=editorRef.current.parentElement.getBoundingClientRect();
          setImgPanel({show:true,x:r2.left-er.left,y:r2.bottom-er.top+8});
        },0);
      }

      img.addEventListener("mousedown",function(e){
        e.preventDefault(); e.stopPropagation(); selectWrapper();
        var editor=editorRef.current,sx=e.clientX,sy=e.clientY;
        var dragging=false,ghost=null;
        function onMove(ev){
          if(!dragging&&(Math.abs(ev.clientX-sx)>4||Math.abs(ev.clientY-sy)>4)){
            dragging=true; wrapper.style.opacity="0.4";
            ghost=document.createElement("div");
            ghost.style.cssText="position:fixed;pointer-events:none;z-index:9999;border:2px dashed #1a73e8;background:rgba(26,115,232,0.08);border-radius:4px;";
            ghost.style.width=img.offsetWidth+"px"; ghost.style.height=img.offsetHeight+"px";
            document.body.appendChild(ghost);
          }
          if(dragging&&ghost){ ghost.style.left=(ev.clientX-img.offsetWidth/2)+"px"; ghost.style.top=(ev.clientY-img.offsetHeight/2)+"px"; }
        }
        function onUp(ev){
          document.removeEventListener("mousemove",onMove); document.removeEventListener("mouseup",onUp);
          if(ghost){ ghost.remove(); ghost=null; } wrapper.style.opacity="1";
          if(!dragging) return;
          var range=null;
          if(document.caretRangeFromPoint) range=document.caretRangeFromPoint(ev.clientX,ev.clientY);
          else if(document.caretPositionFromPoint){ var pos=document.caretPositionFromPoint(ev.clientX,ev.clientY); if(pos){range=document.createRange();range.setStart(pos.offsetNode,pos.offset);} }
          if(range&&editor.contains(range.startContainer)){
            var parent=wrapper.parentNode; if(parent) parent.removeChild(wrapper);
            range.insertNode(wrapper);
            wrapper.parentNode.insertBefore(document.createTextNode("\u200B"),wrapper.nextSibling);
          }
          selectWrapper();
        }
        document.addEventListener("mousemove",onMove); document.addEventListener("mouseup",onUp);
      });
    });
  },[]);

  function handleImageUpload(e){
    var file=e.target.files[0]; if(!file) return;
    var reader=new FileReader();
    reader.onload=function(ev){
      restoreRange();
      exec("insertHTML","<img src='"+ev.target.result+"' style='width:300px;max-width:100%;vertical-align:middle' class='doc-img'/>");
      setTimeout(setupImages,50);
    };
    reader.readAsDataURL(file); e.target.value="";
  }

  function setImgFloat(f){
    if(!selectedImg) return;
    var w=selectedImg.closest(".img-wrapper"); if(!w) return;
    if(f==="none"){ w.style.cssText="display:inline-block;position:relative;line-height:0;"; selectedImg.style.float="none"; selectedImg.style.margin="4px"; }
    else if(f==="left"){ w.style.cssText="display:block;position:relative;line-height:0;float:left;margin:4px 12px 4px 0;"; }
    else if(f==="right"){ w.style.cssText="display:block;position:relative;line-height:0;float:right;margin:4px 0 4px 12px;"; }
    setImgPanel(function(p){ return {...p,show:false}; });
  }
  function setImgSize(w){
    if(!selectedImg) return;
    var ar=selectedImg.offsetWidth/selectedImg.offsetHeight;
    selectedImg.style.width=w+"px"; selectedImg.style.height=(w/ar)+"px";
    setImgPanel(function(p){ return {...p,show:false}; });
  }
  function deleteImg(){
    if(selectedImg){ var w=selectedImg.closest(".img-wrapper"); if(w) w.remove(); else selectedImg.remove(); }
    setSelectedImg(null); setImgPanel({show:false,x:0,y:0});
  }

  useEffect(function(){
    var el=editorRef.current; if(!el) return;
    el.innerHTML="<p style='font-family:Arial;font-size:12pt;line-height:1.15'>Start typing your document here...</p>";
    function onInput(){ setupImages(); updateActive(); }
    el.addEventListener("input",onInput);
    el.addEventListener("keyup",function(){ saveRange(); updateActive(); });
    el.addEventListener("mouseup",function(){ saveRange(); updateActive(); });
    el.addEventListener("click",function(e){ if(!e.target.closest(".img-wrapper")) clearAllWrappers(); });
    return function(){ el.removeEventListener("input",onInput); };
  },[setupImages]);

  function row(children){
    return (
      <div className="ee-toolbar-row">
        {children}
      </div>
    );
  }

  return (
    <div className="envelope-editor-root">
      <div className="ee-toolbar-shell">
        {row(<>
          <TBtn title="Undo" onClick={function(){exec("undo");}}>↩</TBtn>
          <TBtn title="Redo" onClick={function(){exec("redo");}}>↪</TBtn>
          <ToolbarDivider/>
          <TBtn title="Open .html or .txt" onClick={function(){docUploadRef.current&&docUploadRef.current.click();}}>📂 Open</TBtn>
          <TBtn title="Download HTML" onClick={downloadHTML}>⬇ HTML</TBtn>
          <TBtn title="Download TXT" onClick={downloadTXT}>⬇ TXT</TBtn>
          <TBtn title="Download DOCX" onClick={downloadDOCX}>⬇ DOCX</TBtn>
          <TBtn title="Print / Save PDF" onClick={printDoc}>🖨 Print</TBtn>
          <ToolbarDivider/>
          <Dropdown value={fontFamily} width={130} options={FONTS} onChange={applyFont}/>
          <ToolbarDivider/>
          <Dropdown value={fontSize} width={60} options={FONT_SIZES.map(function(s){return {val:String(s),label:String(s)};})} onChange={applySize}/>
          <ToolbarDivider/>
          <TBtn title="Bold" active={activeFormats.bold} onClick={function(){exec("bold");}}><b>B</b></TBtn>
          <TBtn title="Italic" active={activeFormats.italic} onClick={function(){exec("italic");}}><i>I</i></TBtn>
          <TBtn title="Underline" active={activeFormats.underline} onClick={function(){exec("underline");}}><u>U</u></TBtn>
          <TBtn title="Strikethrough" active={activeFormats.strikeThrough} onClick={function(){exec("strikeThrough");}}><s>S</s></TBtn>
          <TBtn title="Superscript" active={activeFormats.superscript} onClick={function(){exec("superscript");}}>x²</TBtn>
          <TBtn title="Subscript" active={activeFormats.subscript} onClick={function(){exec("subscript");}}>x₂</TBtn>
          <ToolbarDivider/>
          <div title="Text color" className="ee-color-control">
            <span className="ee-color-letter">A</span>
            <div className="ee-color-swatch" style={{background:textColor}}/>
            <input type="color" value={textColor} onChange={function(e){applyColor(e.target.value);}} className="ee-color-input"/>
          </div>
          <div title="Highlight" className="ee-color-control ee-color-control-highlight">
            <span className="ee-highlight-letter">H</span>
            <div className="ee-color-swatch" style={{background:bgColor}}/>
            <input type="color" value={bgColor} onChange={function(e){applyBg(e.target.value);}} className="ee-color-input"/>
          </div>
        </>)}

        {row(<>
          <TBtn title="Align left" active={activeFormats.justifyLeft} onClick={function(){exec("justifyLeft");}}>≡L</TBtn>
          <TBtn title="Align center" active={activeFormats.justifyCenter} onClick={function(){exec("justifyCenter");}}>≡C</TBtn>
          <TBtn title="Align right" active={activeFormats.justifyRight} onClick={function(){exec("justifyRight");}}>≡R</TBtn>
          <TBtn title="Justify" active={activeFormats.justifyFull} onClick={function(){exec("justifyFull");}}>≡J</TBtn>
          <ToolbarDivider/>
          <TBtn title="Bullet list" active={activeFormats.insertUnorderedList} onClick={function(){exec("insertUnorderedList");}}>• List</TBtn>
          <TBtn title="Numbered list" active={activeFormats.insertOrderedList} onClick={function(){exec("insertOrderedList");}}>1. List</TBtn>
          <TBtn title="Indent" onClick={function(){exec("indent");}}>→|</TBtn>
          <TBtn title="Outdent" onClick={function(){exec("outdent");}}>|←</TBtn>
          <ToolbarDivider/>
          <Dropdown value={lineHeight} width={95} options={LINE_HEIGHTS} onChange={applyLineHeight}/>
          <Dropdown value={wordSpacing} width={110}
            options={[{val:"normal",label:"Word Spacing"},{val:"2px",label:"Wide"},{val:"4px",label:"Wider"},{val:"8px",label:"Widest"},{val:"-1px",label:"Tight"}]}
            onChange={applyWordSpacing}/>
          <ToolbarDivider/>
          <TBtn title="H1" onClick={function(){exec("formatBlock","h1");}}>H1</TBtn>
          <TBtn title="H2" onClick={function(){exec("formatBlock","h2");}}>H2</TBtn>
          <TBtn title="H3" onClick={function(){exec("formatBlock","h3");}}>H3</TBtn>
          <TBtn title="Paragraph" onClick={function(){exec("formatBlock","p");}}>P</TBtn>
          <TBtn title="Blockquote" onClick={function(){exec("formatBlock","blockquote");}}>""</TBtn>
          <ToolbarDivider/>
          <TBtn title="Insert link" onClick={insertLink}>Link</TBtn>
          <TBtn title="Insert table" onClick={insertTable}>Table</TBtn>
          <TBtn title="Horizontal rule" onClick={insertHr}>HR</TBtn>
          <TBtn title="Upload image" onClick={function(){ saveRange(); fileInputRef.current&&fileInputRef.current.click(); }}>Image</TBtn>
          <TBtn title="Remove formatting" onClick={function(){exec("removeFormat");}}>Tx</TBtn>
          <ToolbarDivider/>
          <select onMouseDown={function(e){ e.stopPropagation(); saveRange(); }}
            onChange={function(e){ insertMergeField(e.target.value); e.target.value=""; }}
            defaultValue=""
            className="ee-merge-select">
            <option value="" disabled>Insert Field</option>
            {MERGE_FIELDS.map(function(f){ return <option key={f} value={f}>[{f}]</option>; })}
          </select>
          <TBtn className="ee-btn-accent" onClick={function(){setShowPreview(true);}}>Preview</TBtn>
        </>)}
      </div>

      <div className="ee-workspace">
        <div className="ee-page-frame">
          {imgPanel.show && (
            <div onMouseDown={function(e){e.stopPropagation();}}
              className="ee-img-panel"
              style={{left:imgPanel.x,top:imgPanel.y}}>
              <span className="ee-img-panel-title">Float:</span>
              <TBtn onClick={function(){setImgFloat("none");}}>Inline</TBtn>
              <TBtn onClick={function(){setImgFloat("left");}}>Left</TBtn>
              <TBtn onClick={function(){setImgFloat("right");}}>Right</TBtn>
              <ToolbarDivider/>
              <span className="ee-img-panel-title">Width:</span>
              {[150,250,350,500].map(function(w){ return <TBtn key={w} onClick={function(){setImgSize(w);}}>{w}px</TBtn>; })}
              <ToolbarDivider/>
              <TBtn className="ee-btn-danger" onClick={deleteImg}>Delete</TBtn>
            </div>
          )}
          <div ref={editorRef} contentEditable suppressContentEditableWarning
            onInput={function(){ setupImages(); updateActive(); }}
            onKeyUp={function(){ saveRange(); updateActive(); }}
            onMouseUp={function(){ saveRange(); updateActive(); }}
            onFocus={updateActive}
            className="ee-editor-content"
          />
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" hidden onChange={handleImageUpload}/>
        <input ref={docUploadRef} type="file" accept=".html,.txt,.docx" hidden onChange={uploadDoc}/>
      </div>

      {showPreview && (
        <div className="ee-preview-overlay"
          onClick={function(e){ if(e.target===e.currentTarget) setShowPreview(false); }}>
          <div className="ee-preview-dialog">
            <div className="ee-preview-header">
              <span className="ee-preview-title">Fill Merge Fields & Preview</span>
              <button onClick={function(){setShowPreview(false);}} className="ee-preview-close">x</button>
            </div>
            <div className="ee-preview-body">
              <div className="ee-preview-fields">
                <p className="ee-preview-help">Enter values for fields used in your document:</p>
                {MERGE_FIELDS.map(function(f){
                  return (
                    <div key={f} className="ee-field-row">
                      <label className="ee-field-label">[{f}]</label>
                      <input value={mergeValues[f]||""} onChange={function(e){setMergeValues(function(v){return {...v,[f]:e.target.value};});}}
                        placeholder={f}
                        className="ee-field-input"/>
                    </div>
                  );
                })}
              </div>
              <div className="ee-preview-pane">
                <div className="ee-preview-page"
                  dangerouslySetInnerHTML={{__html:getPreviewHtml()}}/>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
